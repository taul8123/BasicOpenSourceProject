import pygame
import sys
import shutil
from tkinter import *
from tkinter.filedialog import *

from tkinter import messagebox

def searchfile():
    global filename
    filename = askopenfilename(parent=window, filetypes=(("PNG 파일", "*.png"), ("모든 파일", "*.*")))


# 아래 코드는 다음과 같은 해상도에 맞춰 작성되었습니다. 이외의 해상도에서 정상적인 작동은 확인되지 않았습니다.
width, height = 1920, 1080  # 1920*1080 (윈도우 디스플레이 배율 설정에 따라 원활히 동작되지 않을 수 있습니다.)

Start_Screen = True
MoveToolbox = False

CheckCode = 9

Erase = 0

CreateBackBlock = 1
CreateBall = 2
CreateBlckhole = 3
CreateFakeWal = 4
CreateMagnetic = 5
CreateMoveWal = 6
CreateStar = 7
CreateThorn = 8
CreateWall = 9
CreateSpring = 10
CreateIcicle = 11
CreateLaser = 12

################################################################
# 아래에서 pixel_size(크기)를 지정할 수 있습니다.
# 디스플레이 해상도에 따라 변경시 올바르게 동작하지 않을 수 있습니다.
# 해당 해상도(1920*1080)에서는 최대공약수인 120의 약수만 사용할 것을 권고합니다.
pixel_size = 40
################################################################

display = []

try:
    f = open('map.txt', 'r')
except:
    window = Tk()
    window.title("배경이미지 선택")
    window.geometry("600x500")
    label1 = Label(window, text="선택된 파일 이름")
    label2 = Label(window, text="지정된 배경이미지가 없습니다.배경 이미지를 선택해 주세요!")
    label1.pack()
    label2.pack()

    filename = askopenfilename(parent=window, filetypes=(("PNG 파일", "*.png"), ("모든 파일", "*.*")))
    label2.configure(text=str(filename))
    background = PhotoImage(file=filename)
    label4 = Label(window, image=background)
    label4.pack()
    window.mainloop()
    direct = filename.split('/')
    shutil.copy(filename, './mapeditimage/{0}'.format(direct[-1]))
    filename = direct[-1]

    for i in range(width // pixel_size):
        temp = []
        for j in range(height // pixel_size):
            temp.append("0\n")
        display.append(temp)
else:
    size = f.readline().split(' ')
    width = int(size[0])
    height = int(size[1])
    pixel_size = int(size[2])
    filename = f.readline()
    filename = filename.replace("\n", "")
    for i in range(width//pixel_size):
        temp = []
        for j in range(height//pixel_size):
            line = f.readline()
            temp.append(line)
        display.append(temp)
    f.close()

pygame.init()
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

Start_background = pygame.image.load("mapeditimage/{0}".format(filename))
default_toolbox = pygame.image.load('mapeditimage/toolbox.png')
default_move = pygame.image.load('mapeditimage/move.png')
default_eraser = pygame.image.load('mapeditimage/eraser.png')
default_select = pygame.image.load('mapeditimage/select.png')
default_xmark = pygame.image.load('mapeditimage/xmark.png')

default_backblock = pygame.image.load('mapeditimage/backblock.png')
default_ball = pygame.image.load('mapeditimage/ball.png')
default_blckhole = pygame.image.load('mapeditimage/blckhole.png')
default_fakewal = pygame.image.load('mapeditimage/fakewal.png')
default_magnetic = pygame.image.load('mapeditimage/magnetic.png')
default_movewal = pygame.image.load('mapeditimage/movewal.png')
default_star = pygame.image.load('mapeditimage/star.png')
default_thorn = pygame.image.load('mapeditimage/thorn.png')
default_wall = pygame.image.load('mapeditimage/wall.png')
default_spring = pygame.image.load('mapeditimage/spring.png')
default_icicle = pygame.image.load('mapeditimage/icicle.png')
default_laser = pygame.image.load('mapeditimage/laser.png')
default_endpoint = pygame.image.load('mapeditimage/endpoint.png')

class newicon():
    def __init__(self, x, y, blocktype, width, height):
        self.x = x
        self.y = y
        self.blocktype = blocktype
        self.width = width
        self.height = height

    def isOver(self, pos):
        if self.x < pos[0] < self.x + self.width:
            if self.y < pos[1] < self.y + self.height:
                return True

# 파일 입력 수정

size = 0

#크기조정
Start_background = pygame.transform.scale(Start_background, (width, height))
default_toolbox = pygame.transform.scale(default_toolbox, (pixel_size * 7, pixel_size*2))
default_move = pygame.transform.scale(default_move, (int(pixel_size/2), int(pixel_size/2)))
default_eraser = pygame.transform.scale(default_eraser, (pixel_size, pixel_size))
default_select = pygame.transform.scale(default_select, (pixel_size+2, pixel_size+2))

default_backblock = pygame.transform.scale(default_backblock, (pixel_size, pixel_size))
default_ball = pygame.transform.scale(default_ball, (pixel_size, pixel_size))
default_blckhole = pygame.transform.scale(default_blckhole, (pixel_size, pixel_size))
default_fakewal = pygame.transform.scale(default_fakewal, (pixel_size, pixel_size))
default_magnetic = pygame.transform.scale(default_magnetic, (pixel_size, pixel_size))
default_movewal = pygame.transform.scale(default_movewal, (pixel_size, pixel_size))
default_star = pygame.transform.scale(default_star, (pixel_size, pixel_size))
default_thorn = pygame.transform.scale(default_thorn, (pixel_size, pixel_size))
default_wall = pygame.transform.scale(default_wall, (pixel_size, pixel_size))
default_spring = pygame.transform.scale(default_spring, (pixel_size, pixel_size))
default_icicle = pygame.transform.scale(default_icicle, (pixel_size, pixel_size))
default_laser = pygame.transform.scale(default_laser, (pixel_size, pixel_size))
default_endpoint = pygame.transform.scale(default_endpoint, (pixel_size, pixel_size))


#아이콘 객체 생성
toolbox = newicon(0, 0, "toolbox", pixel_size*7, pixel_size*2)
move = newicon(toolbox.x, toolbox.y, "move", int(pixel_size/2), int(pixel_size/2))
eraser = newicon(toolbox.x + pixel_size*6, toolbox.y + pixel_size*1, "eraser", pixel_size, pixel_size)
select = newicon(toolbox.x + pixel_size*4 - 1, toolbox.y + pixel_size * 1 - 1, "select", pixel_size+2, pixel_size+2)
xmark = newicon(0, 0, "xmark", pixel_size, pixel_size)

backblock = newicon(toolbox.x + pixel_size*1, toolbox.y, "backblock", pixel_size, pixel_size)
ball = newicon(toolbox.x + pixel_size*2, toolbox.y, "ball", pixel_size, pixel_size)
blckhole = newicon(toolbox.x + pixel_size*3, toolbox.y, "blckhole", pixel_size, pixel_size)
fakewal = newicon(toolbox.x + pixel_size*4, toolbox.y, "fakewal", pixel_size, pixel_size)
magnetic = newicon(toolbox.x + pixel_size*5, toolbox.y, "magnetic", pixel_size, pixel_size)
movewal = newicon(toolbox.x + pixel_size*1, toolbox.y + pixel_size*1, "movewal", pixel_size, pixel_size)
star = newicon(toolbox.x + pixel_size*2, toolbox.y + pixel_size*1, "star", pixel_size, pixel_size)
thorn = newicon(toolbox.x + pixel_size*3, toolbox.y + pixel_size*1, "thorn", pixel_size, pixel_size)
wall = newicon(toolbox.x + pixel_size*4, toolbox.y + pixel_size*1, "wall", pixel_size, pixel_size)
spring = newicon(toolbox.x, toolbox.y + pixel_size*1, "spring", pixel_size, pixel_size)
icicle = newicon(toolbox.x + pixel_size*5, toolbox.y + pixel_size*1, "icicle", pixel_size, pixel_size)
laser = newicon(toolbox.x + pixel_size*6, toolbox.y, "laser", pixel_size, pixel_size)
endpoint = newicon(0, 0, "endpoint", pixel_size, pixel_size)

while True:
    if Start_Screen:
        screen.blit(Start_background, (0, 0))

        for i in range(width//pixel_size):
            for j in range(height//pixel_size):
                pygame.draw.rect(screen, (50, 50, 50), [i*pixel_size, j*pixel_size, pixel_size, pixel_size], 1)

        for i in range(width//pixel_size):
            for j in range(height//pixel_size):
                if display[i][j].find('backblock') != -1:
                    screen.blit(default_backblock, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('ball') != -1:
                    screen.blit(default_ball, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('blckhole') != -1:
                    screen.blit(default_blckhole, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('fakewal') != -1:
                    screen.blit(default_fakewal, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('magnetic') != -1:
                    screen.blit(default_magnetic, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('movewal') != -1:
                    screen.blit(default_movewal, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('endpoint') != -1:
                    screen.blit(default_endpoint, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('star') != -1:
                    screen.blit(default_star, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('thorn') != -1:
                    screen.blit(default_thorn, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('wall') != -1:
                    screen.blit(default_wall, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('spring') != -1:
                    screen.blit(default_spring, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('icicle') != -1:
                    screen.blit(default_icicle, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('laser') != -1:
                    screen.blit(default_laser, (i * pixel_size, j * pixel_size))
                else:
                    continue

        screen.blit(default_toolbox, (toolbox.x, toolbox.y))
        screen.blit(default_move, (move.x, move.y))
        screen.blit(default_eraser, (eraser.x, eraser.y))

        screen.blit(default_backblock, (backblock.x, backblock.y))
        screen.blit(default_ball, (ball.x, ball.y))
        screen.blit(default_blckhole, (blckhole.x, blckhole.y))
        screen.blit(default_fakewal, (fakewal.x, fakewal.y))
        screen.blit(default_magnetic, (magnetic.x, magnetic.y))
        screen.blit(default_movewal, (movewal.x, movewal.y))
        screen.blit(default_star, (star.x, star.y))
        screen.blit(default_thorn, (thorn.x, thorn.y))
        screen.blit(default_wall, (wall.x, wall.y))
        screen.blit(default_spring, (spring.x, spring.y))
        screen.blit(default_icicle, (icicle.x, icicle.y))
        screen.blit(default_laser, (laser.x, laser.y))

    for event in pygame.event.get():
        pos = pygame.mouse.get_pos()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                f = open('map.txt', 'w')
                save = str(width) + " " + str(height) + " " + str(pixel_size) + "\n"
                f.write(save)
                f.write(filename + "\n")
                for i in range(width // pixel_size):
                    for j in range(height // pixel_size):
                        f.write(display[i][j])
                f.close()
                pygame.quit()
                sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            if backblock.isOver(pos):
                CheckCode = CreateBackBlock
                select.x, select.y = backblock.x - 1, backblock.y - 1
            elif ball.isOver(pos):
                CheckCode = CreateBall
                select.x, select.y = ball.x - 1, ball.y - 1
            elif blckhole.isOver(pos):
                CheckCode = CreateBlckhole
                select.x, select.y = blckhole.x - 1, blckhole.y - 1
            elif fakewal.isOver(pos):
                CheckCode = CreateFakeWal
                select.x, select.y = fakewal.x - 1, fakewal.y - 1
            elif magnetic.isOver(pos):
                CheckCode = CreateMagnetic
                select.x, select.y = magnetic.x - 1, magnetic.y - 1
            elif movewal.isOver(pos):
                CheckCode = CreateMoveWal
                select.x, select.y = movewal.x - 1, movewal.y - 1
            elif star.isOver(pos):
                CheckCode = CreateStar
                select.x, select.y = star.x - 1, star.y - 1
            elif thorn.isOver(pos):
                CheckCode = CreateThorn
                select.x, select.y = thorn.x - 1, thorn.y - 1
            elif wall.isOver(pos):
                CheckCode = CreateWall
                select.x, select.y = wall.x - 1, wall.y - 1
            elif spring.isOver(pos):
                CheckCode = CreateSpring
                select.x, select.y = spring.x - 1, spring.y - 1
            elif icicle.isOver(pos):
                CheckCode = CreateIcicle
                select.x, select.y = icicle.x - 1, icicle.y - 1
            elif laser.isOver(pos):
                CheckCode = CreateLaser
                select.x, select.y = laser.x - 1, laser.y - 1

            elif eraser.isOver(pos):
                CheckCode = Erase
                select.x, select.y = eraser.x - 1, eraser.y - 1

            elif move.isOver(pos):
                MoveToolbox = True
            else:
                continue

        if MoveToolbox and event.type == pygame.MOUSEBUTTONUP:
            CheckCode = -1
            toolbox.x, toolbox.y = pos[0], pos[1]
            move.x, move.y = toolbox.x, toolbox.y
            eraser.x, eraser.y = toolbox.x + pixel_size * 6, toolbox.y + pixel_size * 1

            backblock.x, backblock.y = toolbox.x + pixel_size * 1, toolbox.y
            ball.x, ball.y = toolbox.x + pixel_size * 2, toolbox.y
            blckhole.x, blckhole.y = toolbox.x + pixel_size * 3, toolbox.y
            fakewal.x, fakewal.y = toolbox.x + pixel_size * 4, toolbox.y
            magnetic.x, magnetic.y = toolbox.x + pixel_size * 5, toolbox.y
            movewal.x, movewal.y = toolbox.x + pixel_size * 1, toolbox.y + pixel_size * 1
            star.x, star.y = toolbox.x + pixel_size * 2, toolbox.y + pixel_size * 1
            thorn.x, thorn.y = toolbox.x + pixel_size * 3, toolbox.y + pixel_size * 1
            wall.x, wall.y = toolbox.x + pixel_size * 4, toolbox.y + pixel_size * 1
            spring.x, spring.y = toolbox.x, toolbox.y + pixel_size * 1
            icicle.x, icicle.y = toolbox.x + pixel_size * 5, toolbox.y + pixel_size * 1
            laser.x, laser.y = toolbox.x + pixel_size * 6, toolbox.y
            MoveToolbox = False

        if CheckCode == 0 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "0\n"

        #저장방식 ['blocktype' 'x위치' 'y위치' 'pixel_size' '방향' '기타 x위치' '기타 y위치']
        #방향 0: 12시 방향(default), 1: 3시 방향, 2: 6시 방향, 3: 9시 방향
        elif CheckCode == 1 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "backblock" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 2 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "ball" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 3 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "blckhole" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 4 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "fakewal" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 5 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "magnetic" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 6 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            if x > width//pixel_size:
                print("오른쪽 공간을 비워주세요!")
                continue
            display[x][y] = "movewal" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + str(x+1*pixel_size) + " " + str(y*pixel_size) + "\n"
            display[x+1][y] = "endpoint" + " " + str(x+1*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + "\n"

        elif CheckCode == 7 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "star" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 8 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "thorn" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 9 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "wall" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 10 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "spring" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 11 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "icicle" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        elif CheckCode == 12 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0] // pixel_size, pos[1] // pixel_size
            display[x][y] = "laser" + " " + str(x * pixel_size) + " " + str(y * pixel_size) + " " + str(pixel_size)\
                            + " " + "0" + " " + "0" + " " + "0" + "\n"

        else:
            continue

        if event.type == pygame.MOUSEBUTTONUP and event.button == 3:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "0\n"


    pygame.display.update()

#최종수정시간:2020.06.06.19.47