import pygame
import sys
pygame.init()
# 아래 코드는 다음과 같은 해상도에 맞춰 작성되었습니다 이외의 해상도에서 정상적인 작동은 확인되지 않았습니다.
width, height = 1920, 1080  # 1920*1080 (윈도우 디스플레이 배율 설정에 따라 원활히 동작되지 않을 수 있습니다.)
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

Start_Screen = True
MoveToolbox = False

CheckCode = 9

Erase = 0

CreateBackBlock = 1
CreateBall = 2
CreateBlckhole = 3
CreateFakeWal = 4
CreateMagnetic = 5
CreateMoveWal = 6
CreateStar = 7
CreateThorn = 8
CreateWall = 9
CreateSpring = 10

Start_background = pygame.image.load("mapeditimage/Background.png")
default_toolbox = pygame.image.load('mapeditimage/toolbox.png')
default_move = pygame.image.load('mapeditimage/move.png')
default_eraser = pygame.image.load('mapeditimage/eraser.png')
default_select = pygame.image.load('mapeditimage/select.png')

default_backblock = pygame.image.load('mapeditimage/backblock.png')
default_ball = pygame.image.load('mapeditimage/ball.png')
default_blckhole = pygame.image.load('mapeditimage/blckhole.png')
default_fakewal = pygame.image.load('mapeditimage/fakewal.png')
default_magnetic = pygame.image.load('mapeditimage/magnetic.png')
default_movewal = pygame.image.load('mapeditimage/movewal.png')
default_star = pygame.image.load('mapeditimage/star.png')
default_thorn = pygame.image.load('mapeditimage/thorn.png')
default_wall = pygame.image.load('mapeditimage/wall.png')
default_spring = pygame.image.load('mapeditimage/spring.png')


class newicon():
    def __init__(self, x, y, blocktype, width, height):
        self.x = x
        self.y = y
        self.blocktype = blocktype
        self.width = width
        self.height = height

    def isOver(self, pos):
        if self.x < pos[0] < self.x + self.width:
            if self.y < pos[1] < self.y + self.height:
                return True

################################################################
# 아래에서 pixel_size(크기)를 지정할 수 있습니다.
# 디스플레이 해상도에 따라 변경시 올바르게 동작하지 않을 수 있습니다.
# 해당 해상도(1920*1080)에서는 최대공약수인 120의 약수만 사용할 것을 권고합니다.
pixel_size = 40
################################################################

display = []

try:
    f = open('map.txt', 'r')
except:
    for i in range(width // pixel_size):
        temp = []
        for j in range(height // pixel_size):
            temp.append("0\n")
        display.append(temp)
else:
    size = f.readline().split(' ')
    width = int(size[0])
    height = int(size[1])
    pixel_size = int(size[2])
    for i in range(width//pixel_size):
        temp = []
        for j in range(height//pixel_size):
            line = f.readline()
            temp.append(line)
        display.append(temp)
    f.close()

# 파일 입력 수정

size = 0

#크기조정
default_toolbox = pygame.transform.scale(default_toolbox, (pixel_size * 6, pixel_size*2))
default_move = pygame.transform.scale(default_move, (int(pixel_size/2), int(pixel_size/2)))
default_eraser = pygame.transform.scale(default_eraser, (pixel_size, pixel_size))
default_select = pygame.transform.scale(default_select, (pixel_size+2, pixel_size+2))

default_backblock = pygame.transform.scale(default_backblock, (pixel_size, pixel_size))
default_ball = pygame.transform.scale(default_ball, (pixel_size, pixel_size))
default_blckhole = pygame.transform.scale(default_blckhole, (pixel_size, pixel_size))
default_fakewal = pygame.transform.scale(default_fakewal, (pixel_size, pixel_size))
default_magnetic = pygame.transform.scale(default_magnetic, (pixel_size, pixel_size))
default_movewal = pygame.transform.scale(default_movewal, (pixel_size, pixel_size))
default_star = pygame.transform.scale(default_star, (pixel_size, pixel_size))
default_thorn = pygame.transform.scale(default_thorn, (pixel_size, pixel_size))
default_wall = pygame.transform.scale(default_wall, (pixel_size, pixel_size))
default_spring = pygame.transform.scale(default_spring, (pixel_size, pixel_size))

#아이콘 객체 생성
toolbox = newicon(0, 0, "toolbox", pixel_size*6, pixel_size*2)
move = newicon(toolbox.x, toolbox.y, "move", int(pixel_size/2), int(pixel_size/2))
eraser = newicon(toolbox.x + pixel_size*5, toolbox.y + pixel_size*1, "eraser", pixel_size, pixel_size)
select = newicon(toolbox.x + pixel_size*4 - 1, toolbox.y + pixel_size * 1 - 1, "select", pixel_size+2, pixel_size+2)

backblock = newicon(toolbox.x + pixel_size*1, toolbox.y, "backblock", pixel_size, pixel_size)
ball = newicon(toolbox.x + pixel_size*2, toolbox.y, "ball", pixel_size, pixel_size)
blckhole = newicon(toolbox.x + pixel_size*3, toolbox.y, "blckhole", pixel_size, pixel_size)
fakewal = newicon(toolbox.x + pixel_size*4, toolbox.y, "fakewal", pixel_size, pixel_size)
magnetic = newicon(toolbox.x + pixel_size*5, toolbox.y, "magnetic", pixel_size, pixel_size)
movewal = newicon(toolbox.x + pixel_size*1, toolbox.y + pixel_size*1, "movewal", pixel_size, pixel_size)
star = newicon(toolbox.x + pixel_size*2, toolbox.y + pixel_size*1, "star", pixel_size, pixel_size)
thorn = newicon(toolbox.x + pixel_size*3, toolbox.y + pixel_size*1, "thorn", pixel_size, pixel_size)
wall = newicon(toolbox.x + pixel_size*4, toolbox.y + pixel_size*1, "wall", pixel_size, pixel_size)
spring = newicon(toolbox.x, toolbox.y + pixel_size*1, "spring", pixel_size, pixel_size)


while True:
    if Start_Screen:
        screen.blit(Start_background, (0, 0))

        for i in range(width//pixel_size):
            for j in range(height//pixel_size):
                pygame.draw.rect(screen, (50, 50, 50), [i*pixel_size, j*pixel_size, pixel_size, pixel_size], 1)

        for i in range(width//pixel_size):
            for j in range(height//pixel_size):
                if display[i][j].find('backblock') != -1:
                    screen.blit(default_backblock, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('ball') != -1:
                    screen.blit(default_ball, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('blckhole') != -1:
                    screen.blit(default_blckhole, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('fakewal') != -1:
                    screen.blit(default_fakewal, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('magnetic') != -1:
                    screen.blit(default_magnetic, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('movewal') != -1:
                    screen.blit(default_movewal, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('star') != -1:
                    screen.blit(default_star, (i*pixel_size, j*pixel_size))
                elif display[i][j].find('thorn') != -1:
                    screen.blit(default_thorn, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('wall') != -1:
                    screen.blit(default_wall, (i * pixel_size, j * pixel_size))
                elif display[i][j].find('spring') != -1:
                    screen.blit(default_spring, (i * pixel_size, j * pixel_size))
                else:
                    continue

        screen.blit(default_toolbox, (toolbox.x, toolbox.y))
        screen.blit(default_move, (move.x, move.y))
        screen.blit(default_eraser, (eraser.x, eraser.y))

        screen.blit(default_backblock, (backblock.x, backblock.y))
        screen.blit(default_ball, (ball.x, ball.y))
        screen.blit(default_blckhole, (blckhole.x, blckhole.y))
        screen.blit(default_fakewal, (fakewal.x, fakewal.y))
        screen.blit(default_magnetic, (magnetic.x, magnetic.y))
        screen.blit(default_movewal, (movewal.x, movewal.y))
        screen.blit(default_star, (star.x, star.y))
        screen.blit(default_thorn, (thorn.x, thorn.y))
        screen.blit(default_wall, (wall.x, wall.y))
        screen.blit(default_spring, (spring.x, spring.y))

    for event in pygame.event.get():
        pos = pygame.mouse.get_pos()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                f = open('map.txt', 'w')
                save = str(width) + " " + str(height) + " " + str(pixel_size) + "\n"
                f.write(save)
                for i in range(width // pixel_size):
                    for j in range(height // pixel_size):
                        f.write(display[i][j])
                f.close()
                pygame.quit()
                sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            if backblock.isOver(pos):
                CheckCode = CreateBackBlock
                select.x, select.y = backblock.x - 1, backblock.y - 1
            elif ball.isOver(pos):
                CheckCode = CreateBall
                select.x, select.y = ball.x - 1, ball.y - 1
            elif blckhole.isOver(pos):
                CheckCode = CreateBlckhole
                select.x, select.y = blckhole.x - 1, blckhole.y - 1
            elif fakewal.isOver(pos):
                CheckCode = CreateFakeWal
                select.x, select.y = fakewal.x - 1, fakewal.y - 1
            elif magnetic.isOver(pos):
                CheckCode = CreateMagnetic
                select.x, select.y = magnetic.x - 1, magnetic.y - 1
            elif movewal.isOver(pos):
                CheckCode = CreateMoveWal
                select.x, select.y = movewal.x - 1, movewal.y - 1
            elif star.isOver(pos):
                CheckCode = CreateStar
                select.x, select.y = star.x - 1, star.y - 1
            elif thorn.isOver(pos):
                CheckCode = CreateThorn
                select.x, select.y = thorn.x - 1, thorn.y - 1
            elif wall.isOver(pos):
                CheckCode = CreateWall
                select.x, select.y = wall.x - 1, wall.y - 1
            elif spring.isOver(pos):
                CheckCode = CreateSpring
                select.x, select.y = spring.x - 1, spring.y - 1
            elif eraser.isOver(pos):
                CheckCode = Erase
                select.x, select.y = eraser.x - 1, eraser.y - 1

            elif move.isOver(pos):
                MoveToolbox = True
            else:
                continue

        if MoveToolbox and event.type == pygame.MOUSEBUTTONUP:
            CheckCode = -1
            toolbox.x, toolbox.y = pos[0], pos[1]
            move.x, move.y = toolbox.x, toolbox.y
            eraser.x, eraser.y = toolbox.x + pixel_size * 5, toolbox.y + pixel_size * 1

            backblock.x, backblock.y = toolbox.x + pixel_size * 1, toolbox.y
            ball.x, ball.y = toolbox.x + pixel_size * 2, toolbox.y
            blckhole.x, blckhole.y = toolbox.x + pixel_size * 3, toolbox.y
            fakewal.x, fakewal.y = toolbox.x + pixel_size * 4, toolbox.y
            magnetic.x, magnetic.y = toolbox.x + pixel_size * 5, toolbox.y
            movewal.x, movewal.y = toolbox.x + pixel_size * 1, toolbox.y + pixel_size * 1
            star.x, star.y = toolbox.x + pixel_size * 2, toolbox.y + pixel_size * 1
            thorn.x, thorn.y = toolbox.x + pixel_size * 3, toolbox.y + pixel_size * 1
            wall.x, wall.y = toolbox.x + pixel_size * 4, toolbox.y + pixel_size * 1
            spring.x, spring.y = toolbox.x, toolbox.y + pixel_size * 1
            MoveToolbox = False

        if CheckCode == 0 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "0\n"

        elif CheckCode == 1 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "backblock" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 2 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "ball" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 3 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "blckhole" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 4 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "fakewal" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 5 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "magnetic" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 6 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "movewal" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 7 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "star" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 8 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "thorn" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 9 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "wall" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        elif CheckCode == 10 and event.type == pygame.MOUSEBUTTONUP:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "spring" + " " + str(x*pixel_size) + " " + str(y*pixel_size) + " " + str(pixel_size) + "\n"

        else:
            continue

        if event.type == pygame.MOUSEBUTTONUP and event.button == 3:
            x, y = pos[0]//pixel_size, pos[1]//pixel_size
            display[x][y] = "0\n"


    pygame.display.update()

#최종수정시간:2020.06.06.19.47