import pygame

from obj import Backblock # 추가
from obj import Ball
from obj import Blckhole # 추가
from obj import Fakewall # 추가
from obj import Magnetic # 추가
from obj import Movewall # 추가
from obj import Spring   # 추가
from obj import Star
from obj import Thorn    # 추가
from obj import Wall


def loadmap(screen):
    backblock_list = pygame.sprite.Group()
    #ball_list = pygame.sprite.Group()
    blckhole_list = pygame.sprite.Group()
    fakewal_list = pygame.sprite.Group()
    magnetic_list = pygame.sprite.Group()
    movewal_list = pygame.sprite.Group()
    #star_list = pygame.sprite.Group()
    thorn_list = pygame.sprite.Group()
    wall_list = pygame.sprite.Group()       # 벽들을 모아둘 그룹
    spring_list = pygame.sprite.Group()


    backblock_image = pygame.image.load('mapeditimage/move.png')
    ball_image = pygame.image.load('mapeditimage/ball.png')
    blckhole_image = pygame.image.load('mapeditimage/blckhole.png')
    fakewal_image = pygame.image.load('mapeditimage/fakewal.png')
    magnetic_image = pygame.image.load('mapeditimage/magnetic.png')
    movewal_image = pygame.image.load('mapeditimage/movewal.png')
    star_image = pygame.image.load('mapeditimage/star.png')
    thorn_image = pygame.image.load('mapeditimage/thorn.png')
    wall_image = pygame.image.load('mapeditimage/wall.png')
    spring_image = pygame.image.load('mapeditimage/spring.png')


    try:
        f = open('map.txt', 'r')
    except:
        print("불러올 맵이 존재하지 않습니다.\a")
        return -1

    size = f.readline().split(' ')
    width = int(size[0])
    height = int(size[1])
    pixel_size = int(size[2])
    while True:
        line = f.readline()
        if not line:
            break
        if line == 0:
            continue
        #temp = ['블럭형태', 'x좌표','y좌표','픽셀크기(정사각형임)']
        temp = line.split(' ')
        if temp[0].find('backblock') != -1:
            continue
            backblock_list.add(Backblock.Backblock(backblock_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('ball') != -1:
            ball = Ball.Ball(ball_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3])))
        elif temp[0].find('blckhole') != -1:
            blckhole_list.add(Blckhole.Blackhole(blckhole_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('fakewal') != -1:
            fakewal_list.add(Fakewall.Fakewall(fakewal_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('magnetic') != -1:
            magnetic_list.add(Magnetic.Magnetic(magnetic_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('movewal') != -1:
            continue
            movewal_list.add(Movewall.Movewall(movewal_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('star') != -1:
            star = Star.Star(star_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3])))
        elif temp[0].find('thorn') != -1:
            thorn_list.add(Thorn.Thorn(thorn_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('wall') != -1:
            wall_list.add(Wall.Wall(wall_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        elif temp[0].find('spring') != -1:
            spring_list.add(Spring.Spring(spring_image, (int(temp[1]), int(temp[2])), (int(temp[3]), int(temp[3]))))
        else:
            continue

    f.close()


#여기는 나중에 어떻게 해야될것 같다
    try:
        return [backblock_list, ball, blckhole_list, fakewal_list, magnetic_list, movewal_list, star, thorn_list, wall_list, spring_list]
    except:
        print("시작지점 혹은 종료지점이 존재하지 않습니다.\a")
        return -1

